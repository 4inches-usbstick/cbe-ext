remote connection via chatbox engine
THIS IS FOR WINDOWS ONLY

this is the client that goes on the PC to be controlled.
it takes instructions either from a local file or a Chatbox on a Chatbox Engine server.

at first it will ask you for details:
you can either use a local file for instructions or a remote Chatbox.


IF USING A LOCAL FILE:
Enter that you want to use a local file, then the filepath, then the refresh rate (how often to open the file and check for new instructions).

IF USING A REMOTE CHATBOX:
Enter that you want to use a remote Chatbox, then the Chatbox number, then the refresh rate, then the IP or domain name of the server to connect to, then the admin password on the server.
If you don't have the admin password the Chatbox will get stuck on one command which will execute over and over (this client uses the CBE 'wipe' command).

COMMANDS:
shell;<cmd> - run a CMD command
transfer;<path> - transfer a local file to the Chatbox media folder (only works if the PC being controlled is the server)
uac;<option> - options: lock, shutdown, restart. figure it out
msg;<message> - bring up a shell window with a message.
url;<url> - opens a link on the PC being controlled