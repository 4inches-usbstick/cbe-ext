
<form action="inchat_joinpage_process-es.php" method="post">
<fieldset>
<legend>Cambiar su nombre y connectar al Chatbox</legend>
<br>
 <input type="hidden" name="nums" size="100" height="10" value=<?=$_GET["chatnum"]; ?>>
 <input type="hidden" name="refreshrate" size="100" height="10" value=<?=$_GET["refreshrate"]; ?>> 
 <input type="hidden" name="enc" size="100" height="10" value=<?=$_GET["encoderm"]; ?>> 
  <input type="hidden" name="bbg" size="100" height="10" value=<?=$_GET["bbg"]; ?>> 
<b>Nombre: </b> <input type="text" name="name" size="100" height="10"> <br>


div<input type="radio" id="male" name="option" value="div" checked='checked'>


<br>
<input type="submit" value="Connectar" style="color:black">
</fieldset>
</form>