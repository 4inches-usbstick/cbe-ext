Diags
<?php
date_default_timezone_set('America/New_York');
//error_reporting(0);
$myfile = fopen("$_GET[write]", "a");

//check for iframes or js, security measure
$iframe = substr_count($_GET["msg"], 'iframe');
$script = substr_count($_GET["msg"], 'script');

if ($iframe > 0 or $script > 0) {
	die("Illegal element found in string detected, halted.<br>");
}
//end that


//ts on?
$contents = file_get_contents("C:/wamp64/www/textengine/sitechats/$_GET[write]");
//echo("$contents, C:/wamp64/www/textengine/sitechats/$_GET[write]");
$needle = "rule.Timestamps(1)";
$timestamps = strpos("$contents", "rule.Timestamps(1)");
echo("<br><br>timestamps at $timestamps<br>");

//encoding yes
$mess = $_GET["msg"];
$emptyencode = empty($_GET["encode"]);
$coder = $_GET["encode"];

if (empty($coder) or $coder == "UTF-8") {
    //echo('UTF8');
	$coder = "UTF-8";
}

$mess = $_GET["msg"];
$mess1 = mb_convert_encoding($mess, $coder);

if (substr_count($mess1, '--star') > 0) {
	echo("star detected command<br>");
	$star = $mess1;
	$starcounter1 = substr($star, 0, -6);
	echo("$starcounter1<br>");
	$timestampstar = date("H:i:s");
	$beforestar = substr_count(file_get_contents($_GET["write"]), "Message \"$starcounter1\"");
	echo("star1: $starcounter1, seen: $beforestar, timestamp: $timestampstar");
	$txt = ("> Starboard: Message \"$starcounter1\" was starred at $timestampstar and has been starred $beforestar times before. <");
	fwrite($myfile, "$txt");
	$URL = $_SERVER['HTTP_REFERER'];
	header("Location: $URL");
	die();
}
	

//$ip = $_SERVER['REMOTE_ADDR'];
//yes ts
$name = $_GET["namer"];

if ($timestamps != "") {
$timestamp1 = date("H:i:s");
$timestamp2 = date("d.m.y");
$txt = "$name [$timestamp1, $timestamp2]: $mess1";
//prevent name gap

if (empty($name)) {
    $txt = "[$timestamp1, $timestamp2]: $mess1";
}

//break check
if ($txt == "escape-break") {
    $txt = "";
}
//end name gap checker
fwrite($myfile, "$txt");
fclose($myfile);
echo("submitted<br>");
$URL = $_SERVER['HTTP_REFERER'];
header("Location: $URL");

//no ts
} else {
$txt = "$name: $mess1";
//namegapfiller
if (empty($name)) {
    $txt = "$mess1";
}
//break check
if ($txt == "escape-break") {
    $txt = "";
}

fwrite($myfile, "$txt");
fclose($myfile);
echo("submitted<br>");
$URL = $_SERVER['HTTP_REFERER'];
header("Location: $URL");
}
echo("$coder encoder<br>");
echo("$mess1 = message<br>");
echo("$name = name<br>")
?>

<p></p>
<form>
 <input type="button" value="← Back" onclick="history.back()">
</form>


