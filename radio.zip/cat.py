#start
import requests as rq
import os
import time

def cls():
    os.system('cls' if os.name=='nt' else 'clear')
    
    

print('Log in: ')
print('-------------')
ip = input('IP> ')
key = input('KEY (or UID::UKEY)> ')
path = ' '
msg_top = ' '
msg_bot = ' '
playlist = ''
uid = False
lists = []

str(ip)
str(key)
str(path)
str(msg_top)
str(msg_bot)

if '::' in key:
    uid = True
    uids = key.split('::')
    print('Using UID instead of key...')
    
cls()

print(' ')
print('Verifying password...')
print('UID instead of key: '+str(uid))

if not uid:
    try:
        pec = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=help&params=0&pass='+str(key), timeout=10)
        pecon = pec.text
        ttr = pec.elapsed.total_seconds()
    except:
        print('Connection has died and the shell will exit in 5 seconds')
        time.sleep(5)
        exit()
if uid:
    try:
        pec = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=help&params=0&uid='+str(uids[0])+'&ukey='+str(uids[1]), timeout=10)
        pecon = pec.text
        ttr = pec.elapsed.total_seconds()
    except:
        print('Connection has died and the shell will exit in 5 seconds')
        time.sleep(5)
        exit()
        
if '[warn:33]' in pecon or pec.status_code != 200:
    print('The password was incorrect or the verification failed and the shell will exit in 5 seconds')
    time.sleep(5)
    exit()
else:
    print('The password was correct and the response time was '+str(ttr))
    print('')
    



#cmd
print('Command line:')
print('-------------')
while True:
    cmd = input('CMD> ')
    cmds = cmd.split(';')
    
    print('')
    
    if cmds[0] == 'path':
        str(cmds[1])
        path = cmds[1]
        print('Path changed to '+path)
    
    if cmds[0] == 'msgtop':
        str(cmds[1])
        offset = cmd.find('>>')
        msg_top = cmd[offset:]
        print('Top content changed to '+msg_top)
        
    if cmds[0] == 'msgbtm':
        str(cmds[1])
        offset = cmd.find('>>')
        msg_top = cmd[offset:]
        print('Bottom content changed to '+msg_bot)
        
    if cmds[0] == 'change':
        str(cmds[1])

        try:
            if not uid:
                req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&pass='+key, timeout=10)
            if uid:
                req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&uid='+uids[0]+'&ukey='+uids[1], timeout=10)
                #print('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&uid='+uids[0]+'&ukey='+uids[1])
                
            req = rq.get('http://'+ip+'/textengine/sitechats/sendmsg_integration.php?encode=UTF-8&write='+path+'&msg='+cmds[1]+';;'+msg_top+';;'+msg_bot, timeout=10)
            print('The current audio file has changed to '+cmds[1])
        except:
            print('Connection has died.')

    if cmds[0] == 'load':
        lists.clear()
        str(cmds[1])
        f = open(cmds[1], 'r')
        playlist = f.read()
        f.close()
        lists = playlist.split(';;')
        print('Playlist loaded')
        
    if cmds[0] == 'httpload':
        lists.clear()
        str(cmds[1])
        
        try:
            req = rq.get(cmds[1], timeout=10)
            reqc = req.text
            lists = reqc.split(';;')
            print('Playlist loaded over HTTP')
        except:
            print('Connection has died.')
        
        
    if cmds[0] == 'playlist':
        for i in lists:
            ats = i.split('==')
            song = ats[0]
            sex = ats[1]
            str(song)
            int(sex)

            try:
                if not uid:
                    req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&pass='+key, timeout=10)
                if uid:
                    req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&uid='+uids[0]+'&ukey='+uids[1], timeout=10)
                    
                req = rq.get('http://'+ip+'/textengine/sitechats/sendmsg_integration.php?encode=UTF-8&write='+path+'&msg='+song+';;'+msg_top+';;'+msg_bot, timeout=10)
                print('The current audio file has changed to '+song+' and will play for '+str(sex)+' seconds')
                print(' ')
            except:
                print('Connection has died.')
                
            time.sleep(int(sex) - 10)

        try:
            if not uid:
                req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&pass='+key, timeout=10)
            if uid:
                req = rq.get('http://'+ip+'/textengine/sitechats/terminalprocess.php?cmd=wipe&params='+path+'&uid='+uids[0]+'&ukey='+uids[1], timeout=10)
            
            req = rq.get('http://'+ip+'/textengine/sitechats/sendmsg_integration.php?encode=UTF-8&write='+path+'&msg='+'uhrukjhrsdsad87346872346278346fa.mp3'+';;'+msg_top+';;'+msg_bot, timeout=10)
            
            print('Transmitter has been silenced')
        except:
            print('Connection has died.')

    if cmds[0] == 'unload':
        lists.clear()
        print('Playlist unloaded')
    
    if cmds[0] == 'exit':
        exit()
    
    if cmds[0] == 'cls':
        cls()



    print('')
            
            
            
        
        
        
    
    
