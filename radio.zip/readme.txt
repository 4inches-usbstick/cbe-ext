this extension allows you to remote control chatboxes and use them as a radio of sorts, where you can assemble playlists or play songs through Chatbox Engine.

when you first open the client you have to connect to the server, and put in the admin password.
then, type in 'path;<chatbox number>'

command list once set up:

msgtop: 'msgtop;<top message content>' - sets the content above the audio element
msgbtm: 'msgbtm;<bottom message content>' - sets the content below the audio element.
change: 'change;<audio-url>' - change the current audio to the URL
load: 'load;<local playlist path>' - load a playlist from the local machine
httpload: 'httpload;<playlist URL>' - load a playlist over HTTP
playlist: 'playlist;0' - play a playlist
unload: 'unload;0' - unload the current playlist
silence: 'silence;0' - silence the Chatbox
exit: 'exit;0' - exit the client
cls: 'cls;0' - clear screen

The client can be run by anything, but inchat-radio must be on because it has special JS that allows it to be used as a radio receiver.

Playlist files:
<song-link>==<song-duration-in-seconds>;;
<next-song-link>==<next-song-duration-in-seconds>;;
etc.