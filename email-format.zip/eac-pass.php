
<?php
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_POST[user]/uploaded/.htapassword");

if ($_POST['password'] != $password) {
	echo("
	Error: verification failed
	
	
	");
	die();
} else {
	$fi = fopen("C:/wamp64/www/textengine/mail-0/media/$_POST[user]/uploaded/.htapassword", 'w');
	fwrite($fi, $_POST['np']);
	fclose($fi);
		header("Location: $_SERVER[HTTP_REFERER]");
}

