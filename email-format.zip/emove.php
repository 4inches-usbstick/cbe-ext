
<?php
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/.htapassword");

if ($_GET['password'] != $password) {
	echo("
	Error: verification failed
	
	
	");
	die();
} else {
	rename("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/$_GET[filename]", "C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/archive/$_GET[filename]");
	header("Location: $_SERVER[HTTP_REFERER]");
}

