
<html>

<title>New Chatbox</title>
<style>

input[type=text] {
  border: 1px solid LightSlateGrey;
  border-radius: 4px;
}

input[type=text]:focus{
  outline: 2px solid Crimson;   
}

</style>


<p>
Open a new account. This account name can only have the 26 letters and numbers, as well as these characters: (- + @ _) </p>
<br><br>
<form action="ewchat.php" method="post">
<fieldset>
<legend>Create a new chatbox</legend>
<br>
Account: <input type="text" name="newname" size="100" height="10"><br>
Password: <input type="password" name="password-email" size="100" height="10"><br>







<input type="hidden" id="allowmed" name="allowmed" value="allowmed" ><br><br>


<input type="submit" value="Create" style="color:black">
</fieldset>
</form>


<!--p>
New Fun:
If you add .html to the end of the Chatbox number, you can get it so by entering elements instead of text into the Chatbox, you can draw in HTML instead of chatting in plain text.
While this is not officially supported, it works. And it's fun. You can also add CSS and JS to customize it to your heart's content. Note however, that anyone can add JS and CSS, so unless you know you are safe, do not use this option. 
You cannot see things like CSS and JS without Inspector, so hidden elements may pose a threat.
<p></p>
However, .html chatboxes are very unsafe, which pose a real problem, so please don't do it. Also, users are advised not to join .html chatboxes they don't trust. Any other file type is also dangerous.
</p-->
</html>

