
<hr>
<a href="javascript:history.back()">Back</a>&nbsp;&nbsp;&nbsp;

<hr>

<?php

$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/.htapassword");

if ($_GET['pass'] != $password) {
	echo("
	<form action='email.php'>
	Verify your identity: 
	<input type='password' id='fname' name='pass'>
	<input type='submit'>
	
	
	");
	die();
} else {
	echo('<div style="white-space: pre;">');
}

chdir("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded");
echo(file_get_contents($_GET['filename']));
echo('</div>');

