
<?php
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_POST[user]/uploaded/.htapassword");

if ($_POST['password'] != $password) {
	echo("
	Error: verification failed
	
	
	");
	die();
} else {
	$whateverthefuckthepasswordis = file_get_contents("C:/wamp64/www/textengine/mail-0/.htapassword");
	$delll = file_get_contents("http://71.255.240.10:8080/textengine/mail-0/terminalprocess.php?cmd=del&params=$_POST[user]&pass=$whateverthefuckthepasswordis");
	echo("Debug: <br><br>$delll");
		header("Location: $_SERVER[HTTP_REFERER]");
}

