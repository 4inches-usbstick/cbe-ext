
<h1>Account Management</h1><hr>
<form action='eac-pass.php' method='post'>
<fieldset>
<legend>Change Password</legend>
Username: <input type="text" name="user" size="100" height="10"><br>
Old Password: <input type="password" name="password" size="100" height="10"><br>
New Password: <input type="password" name="np" size="100" height="10"><br>
<input type="submit">
</fieldset>
<br>
</form>

<form action='eac-del.php' method='post'>
<fieldset>
<legend>Close Account</legend>
Username: <input type="text" name="user" size="100" height="10"><br>
Password: <input type="password" name="password" size="100" height="10"><br>
<input type="submit">
</fieldset>
</form>

