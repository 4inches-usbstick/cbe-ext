
<?php
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_GET[sender]/uploaded/.htapassword");
date_default_timezone_set('America/New_York');

if ($_GET['sender-pass'] != $password) {
	echo("
	Error: verification failed
	
	
	");
	die();
} else {
	echo('<!--l-->');
}

$reci = $_GET['send'];
$recil = explode(';;', $reci);
//echo($recil[1]);
$rand = rand(100000000, 999999999);

$timestamp1 = date("H:i:s");
$timestamp2 = date("d.m.y");
$ts = "[$timestamp1, $timestamp2]";

foreach ($recil as $ii) {
	
$towrite = $_GET["con"];
$iframe = substr_count($towrite, 'iframe');
$script = substr_count($towrite, 'script');
$download = substr_count($towrite, 'download');
$action = substr_count($towrite, 'action');
$brackopen = substr_count($towrite, '<');
$brackclose = substr_count($towrite, '>');

if ($iframe > 0 or $script > 0 or $download > 0 or $action > 0 or $brackopen > 0 or $brackclose > 0) {
	$towrite = "<div style='color:red;'>WARNING: This email may be infected. Do not open it if you do not trust the sender</div><br>" . $_GET["con"];
}
chdir("C:/wamp64/www/textengine/mail-0/media/$ii/uploaded/");
$ff = fopen("$rand.cbemail", "w");
$towrite = "
$towrite\n\nMETADATA;$_GET[sub];$ts;$_GET[sender]
";
fwrite($ff, $towrite);
fclose($ff);
echo($ii);
echo('<br>');
}


