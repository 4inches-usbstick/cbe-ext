
<?php
error_reporting(0);
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/.htapassword");


if ($_GET['pass'] != $password or empty($_GET['acc']) or empty($_GET['pass'])) {
	echo("
	<h1>Sign In</h1>
	<hr>
	<form action='email.php' method='get'>
	Username:
	<input type='text' id='fnamed' name='acc'>
	Password:
	<input type='password' id='fname' name='pass'><br><br><input type='submit'>
	");
	die();
} else {
echo("<h1>Inbox</h1><hr><a href=\"esend.php?sender=$_GET[acc]&pass=$_GET[pass]\">Compose</a>&nbsp;&nbsp;&nbsp;&nbsp;");
echo("<a href=\"eac.php\">Account</a>&nbsp;&nbsp;&nbsp;&nbsp;");
echo("<a href=\"ear.php?acc=$_GET[acc]&pass=$_GET[pass]\">Archives</a>&nbsp;&nbsp;&nbsp;&nbsp;");
echo("<a href=\"javascript:window.location.href=window.location.href\">Reload</a><hr>");
}

chdir("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded");

$images = glob('*.cbemail');

array_multisort(
array_map( 'filemtime', $images ),
SORT_NUMERIC,
SORT_DESC,
$images
);


foreach($images as $filename) {
	$file = file_get_contents($filename);
	$meta_off = stripos($file, 'METADATA');
	$meta = substr($file, $meta_off);
	$pieces = explode(";", $meta);
	$contents = substr($file, 0, $meta_off);
	$contents = substr($contents, 0, 106);
	$url = "emove.php?acc=$_GET[acc]&filename=$filename&password=$_GET[pass]";
	
	echo("<fieldset> <b>Sender:</b> <code>$pieces[3]</code>, 
	<b>Subject:</b> <code>$pieces[1] </code></b>
	<b>Time:</b><code> $pieces[2]</code><br>
	<b>Preview:</b> <code>$contents...</code><br>
	<a href=eview.php?pass=$_GET[pass]&filename=$filename&acc=$_GET[acc]>Open</a>&nbsp;&nbsp;&nbsp;
	<a href=eremove.php?password=$_GET[pass]&filename=$filename&acc=$_GET[acc]>Delete</a>&nbsp;&nbsp;&nbsp
	<a href=$url>Archive</a>&nbsp;&nbsp;&nbsp
	
	</fieldset><br>");
}

