
<title>engine page</title>

<?php
echo("This is a Chatbox Engine processing page. </p></p><hr>");
error_reporting(0);
echo("<b>Attempting to create new chatbox</b><p></p>");
$ok = 1;

$filename = $_POST["newname"];

if (file_exists($filename)) {
    $ok = 0;
	echo("<b>Error: This account is in use.</b> <p></p>");
	die();
} else {
    echo("<p>[1] Complete </p> <p></p>");
}

$haystaq = file_get_contents('C:\wamp64\www\textengine\mail-0\.htabannednumbers');
$findme = $filename;
$pos = stristr($findme, ".");

if ($pos === false) {
    echo "[2] Complete<p></p>";
} else {
    echo "This is a forbidden Chatbox number";
	$ok = 0;
	die();
}



$haystaq = file_get_contents('C:\wamp64\www\textengine\mail-0\.htabannednumbers');
$findme = $filename;
$pos = strpos($haystaq, $findme);

if ($pos === false) {
    echo "[2] Complete<p></p>";
} else {
    echo "This is a forbidden Chatbox number";
	$ok = 0;
	die();
}

$option = $_POST['option'];


$new = "$_POST[newname]";





if ($ok == "1") {
	$newmediadir = "$_POST[newname]";
	echo("[3] Complete <p></p>");
	$myfile = fopen($new, "w");
	
	mkdir("C:/wamp64/www/textengine/mail-0/media/$newmediadir", 0700);
	mkdir("C:/wamp64/www/textengine/mail-0/media/$newmediadir/uploaded", 0700);
	mkdir("C:/wamp64/www/textengine/mail-0/media/$newmediadir/uploaded/archive", 0700);
	
	echo("<b>New Chatbox created with number $new. ");
	$txt = "This is chatbox with number $filename <p></p>.";
	
	chdir("C:/wamp64/www/textengine/mail-0/media/$newmediadir/uploaded");
	$myfile1 = fopen('.htapassword', 'w');
	fwrite($myfile1, $_POST['password-email']);
	fclose($myfile1);
}

	
?>

<a href='http://71.255.240.10:8080/textengine/mail-0/email.php>Sign In</a>


