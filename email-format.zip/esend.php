
<?php
echo("
<form action='esend-process.php' method='get'>
<div id='form' style='white-space: pre;'><code>
Recipient: <input type=\"text\" id=\"send\" name=\"send\"> Subject: <input type=\"text\" id=\"sub\" name=\"sub\"><br><hr>
Content: <br><textarea id=\"content\" name=\"con\" rows=\"10\" cols=\"150\"></textarea>
<input type='hidden' name='sender' value='$_GET[sender]'>
<input type='hidden' name='sender-pass' value='$_GET[pass]'>
<input type='submit' style=\"height:25px;width:135px\" value='Send Message'></code>
");

