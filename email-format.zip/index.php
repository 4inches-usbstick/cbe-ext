
<h1>Index</h1>
<hr>
<a href='email.php'>Sign into an account</a><br>
<a href='enew.php'>Open an account</a><br>
<a href='eac.php'>Account Management</a><br>
<a href='terminal.php'>Administrator Console</a><br>



