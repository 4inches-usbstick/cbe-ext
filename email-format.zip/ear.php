
<h1>Archives</h1>
<hr>
<a href="javascript:history.back()">Back</a>
<hr>
<?php
error_reporting(0);
$password = file_get_contents("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/.htapassword");


if ($_GET['pass'] != $password or empty($_GET['acc']) or empty($_GET['pass'])) {
	echo("
	<h1>Sign In</h1>
	<hr>
	<form action='email.php' method='get'>
	Username:
	<input type='text' id='fnamed' name='acc'>
	Password:
	<input type='password' id='fname' name='pass'><br><br><input type='submit'>
	");
	die();
} else {
$a = 1;
}

chdir("C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/archive");
foreach(glob('*.cbemail') as $filename) {
	$file = file_get_contents($filename);
	$meta_off = stripos($file, 'METADATA');
	$meta = substr($file, $meta_off);
	$pieces = explode(";", $meta);
	$contents = substr($file, 0, $meta_off);
	$contents = substr($contents, 0, 40);
	
	echo("<fieldset> <b>Sender:</b> <code>$pieces[3]</code>, <b>Subject:</b> <code>$pieces[1] </code></b><b>Sent At:</b><code> $pieces[2]</code><br><b>Preview:</b> <code>$contents...</code><br><a href=eview.php?pass=$_GET[pass]&filename=C:/wamp64/www/textengine/mail-0/media/$_GET[acc]/uploaded/archive/$filename&acc=$_GET[acc]>Open</a></fieldset><br>");
}

