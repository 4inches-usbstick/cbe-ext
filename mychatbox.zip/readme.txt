The mychatbox extension allows people to invite other people by IP. 
Use invite::<IP> to invite someone, and lockout::<IP> to uninvite them.

To install, just place map.php or index.php  in sitechats. You won't have to replace anything or modify files for this extension.
index.php is only a table, and map.php is a full page.