<base target="_parent"> 
<h1>Index Page</h1>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 1px 4px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:none;border-width:1px;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:none;border-width:1px;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>
<table class="tg">

<!--thead>
  <tr>
    <th class="tg-0lax">Chatboxes you are invited to: </th>
  </tr>
</thead-->

<tbody>

<ul>
  <li><a href="index.php"><b>My Chatboxes</b> &nbsp;&nbsp;&nbsp;</a></li>
  <li><a href="joinchatpublic.php">Join &nbsp;</a></li>
  <li><a href="createnewchat.php">Create &nbsp;</a></li>
  <li><a href="terminal.php">Terminal &nbsp;</a></li>
  <li><a href="admineditsutil.php">X-Edit &nbsp;</a></li>
  <li><a href="http://71.255.240.10:8080/textengine/sitechats/info">Docs &nbsp;</a></li>
  <li><a href="http://71.255.240.10:8080/textengine/sitechats/info/rules.txt">Rules &nbsp;</a></li>
</ul>

<br><br>
Chatboxes you are invited to: <br><br>
<?php
$counter = 0;
error_reporting(0);
echo "invite::$_SERVER[REMOTE_ADDR]<br>";
foreach (glob("*") as $filename) {
    $file = file_get_contents($filename);
	$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
	$iframe = substr_count($file, "invite::WILDCARD-ALL") + $iframe;
	$oktoinvite = substr_count($file, "uninvite::$_SERVER[REMOTE_ADDR]");
	


	
	if ($iframe > 0 && $oktoinvite == 0 && $filename != 'index.php' && $filename != 'map.php') {
	echo("
	  <tr>
    <td class=\"tg-0lax\"><b>$filename</b></td>
    <td class=\"tg-0lax\"><b><a href='inchat_joinpage.php?chatnum=$filename&refreshrate=5000&explorer=0&encoderm=UTF-8&bbg='>Open this Chatbox</a></td></b>
  </tr>
	
	");
		$counter = $counter + 1;
	}
	

}
if ($counter == 0) {
	echo("<i>You are not a member of any Chatboxes.</i>");
}

?>

</tbody>
</table></p>


</div>
