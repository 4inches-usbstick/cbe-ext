
<b>Chatboxes you are a member of (via IP): </b><br><br>
<base target="_parent"> 

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>
<table class="tg">
<thead>
  <tr>
    <th class="tg-0lax">Chatbox Number</th>
    <th class="tg-0lax">Join Link</th>
  </tr>
</thead>
<tbody>


<?php
$counter = 0;
error_reporting(0);
foreach (glob("*") as $filename) {
    $file = file_get_contents($filename);
	$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
	$iframe = substr_count($file, "invite::WILDCARD-ALL");
	$oktoinvite = substr_count($file, "uninvite::$_SERVER[REMOTE_ADDR]");
	
	if ($iframe > 0 && $oktoinvite == 0 && $filename != 'index.php' && $filename != 'map.php') {
	echo("
	  <tr>
    <td class=\"tg-0lax\"><b>$filename</b></td>
    <td class=\"tg-0lax\"><b><a href='inchat_joinpage.php?chatnum=$filename&refreshrate=5000&explorer=0&encoderm=UTF-8&bbg='>Open this Chatbox</a></td></b>
  </tr>
	
	");
		$counter = $counter + 1;
	}

}

if ($counter == 0) {
	echo("<i>You are not a member of any Chatboxes.</i>");
}

?>

</tbody>
</table></p>


</div>
