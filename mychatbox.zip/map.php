<title>Chatboxes</title>
<h1>Chatbox Hub</h1>
<hr>
<a href='joinchatpublic.php'>Join Chatbox</a><br>
<a href='createnewchat.php'>Create Chatbox</a><br>
<a href='inchat.php?chatnum=04universal-upload&refreshrate=30000&explorer=0&encoderm=UTF-8&name='>04universal-upload [ifr]</a><br>
<a href='inchat-div.php?chatnum=04universal-upload&refreshrate=30000&explorer=0&encoderm=UTF-8&name='>04universal-upload [div]</a><br>
<a href='terminal.php'>Terminal</a><br><hr>

<b>Chatboxes you are a member of (via IP): </b><br><br>

<?php
$counter = 0;
error_reporting(0);
foreach (glob("*") as $filename) {
    $file = file_get_contents($filename);
	$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
	$iframe = substr_count($file, "invite::WILDCARD-ALL");
	$oktoinvite = substr_count($file, "uninvite::$_SERVER[REMOTE_ADDR]");
	
	if ($iframe > 0 && $oktoinvite == 0 && $filename != 'index.php' && $filename != 'map.php') {
	echo("<fieldset>You are a member of Chatbox <b>$filename</b><br><a href='inchat_joinpage.php?chatnum=$filename&refreshrate=5000&explorer=0&encoderm=UTF-8&bbg='>Open this Chatbox</a></fieldset>");
		$counter = $counter + 1;
	}

}

if ($counter == 0) {
	echo("<i>You are not a member of any Chatboxes.</i>");
}