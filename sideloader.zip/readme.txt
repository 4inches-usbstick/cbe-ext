Sideloader:

Just copy paste the files into sitechats directory, and use the terminal command for it.
Make sure to have Python and requests installed.
Replace 'C:\wamp64\www\textengine' with the path you would take to get to a file.
Replace '71.255.240.10:8080' with your server IP or domain name.

The CLI file is a modified version of loader.py that allows you to control the file that is loaded.