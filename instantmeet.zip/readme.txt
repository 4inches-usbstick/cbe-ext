instant meet button added to client for update 1.3.9
present for arjun, who got an entire update to himself