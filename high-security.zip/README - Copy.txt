To install the high security extension,

1. Copy the high-security folder into sitechats.
2. Open all the files in a text editor with a Find and Replace feature.
3. Replace these strings with the new strings:

71.255.240.10:8080 becomes your domain name or IP (with port number);
C:/wamp64/www/textengine becomes the path you take to get to sitechats.


API:
The API is for the most part the same as regular security Chatbox Engine, except in a few places:

> Anytime there is a parameter that wants a Chatbox name, use the full name, which includes the .hta
> The exception to the above rule is while deleting a Chatbox and creating a Chatbox. When using these endpoints, make sure to not include the .hta in the Chatbox name.
> There is no option value for newchat_integration, instead there is a cipher and a protocol value. Opening a ciphered chatbox requires you to set the cipher value to YES as well as
specifying a protocol. Nonciphered Chatboxes don't need a protocol value.
> If there is an parameter that wants name, replace it with pass.

CIPHER:
Using cipher::YES at the beginning after the 16 char password allows you to set the Chatbox to ciphered. It's up to clients to acknowledge the 'ciphered chatbox' flag. Right after
should be the protocol, in this format: protocol::PROTOCOLNAME. Since HS Chatboxes aren't all on one protocol or method, this tells clients which Chatboxes they can actually read.

UID/UKEY and new things:
Everything since 1.4.0 has not been added to the HS extension, because it just wouldn't work the way it's supposed to.

KEYS:
No keys are to be stored on the server. Clients are responsible for working with ciphered text. The server only holds this text.

ENXMAP:
The prepackaged client is for use with the ENXMAP protocol. It won't work with anything else.