To install the high security extension,

1. Copy the high-security folder into sitechats.
2. Open all the files in a text editor with a Find and Replace feature.
3. Replace these strings with the new strings:

71.255.240.10:8080 becomes your domain name or IP (with port number);
C:/wamp64/www/textengine becomes the path you take to get to sitechats.

NOTE: make sure to have a way for users to navigate the various pages.

NEW: you can now invite and ban people from Chatboxes. Use invite::<IP> to invite someone, and lockout::<IP> to ban someone.
To invite someone is to allow them to have access to the Chatbox even without the password.
To ban someone is to forbid the user from ever touching the Chatbox again in any way. (deletion, API, msg sending, etc.)

To make a read-only Chatbox, use invite::WILDCARD-ALL. This makes the Chatbox public, and anyone can read from it. However, people can't write to it. This should usually only be for when a sideloader file is made read-only.

Note that if you are invited to an HS Chatbox via IP, you can see the password, but if you are invited with the wildcard, you cannot see the password.


NEW: go to inchat_nobreak.php if you don't want the <br> tags to be used.
NEW: fordistro is the client that uses enx and cbedata to encode and decode chatboxes

API:
The API is for the most part the same as regular security Chatbox Engine, except in a few places:

> Anytime there is a parameter that wants a Chatbox name, use the full name, which includes the .hta
> The exception to the above rule is while deleting a Chatbox and creating a Chatbox. When using these endpoints, make sure to not include the .hta in the Chatbox name.

> If there is an parameter that wants name, replace it with pass.
> For all API operations, make sure to pass a pass or key argument with '&pass=<PASSWORD>&key=<PASSWORD>' so that you can be sure you're giving the server everything it needs

CIPHER:
Using cipher::YES at the beginning after the 16 char password allows you to set the Chatbox to ciphered. Note that this does not use one  ciphering standard only. cipher::YES only marks the Chatbox as ciphered, so regular noncipher clients can't touch it and mess something up.