<?
error_reporting(0);
?>

<form action="inchat_joinpage_process.php" method="post">
<fieldset>
<legend>Join High Security Chatbox</legend>
<br>
 Chatbox Number: <input type="text" name="nums" size="100" height="10" value=<?=$_GET["chatnum"]; ?>><br>
 <input type="hidden" name="refreshrate" size="100" height="10" value=<?=$_GET["refreshrate"]; ?>> 
 <input type="hidden" name="enc" size="100" height="10" value=<?=$_GET["encoderm"]; ?>> 
  <input type="hidden" name="bbg" size="100" height="10" value='0'> 
Password: <input type="password" name="name" size="100" height="10"> <br>


<br>
<input type="submit" value="Join" style="color:black">
</fieldset>
</form>