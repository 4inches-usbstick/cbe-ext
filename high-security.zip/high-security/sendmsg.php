Diags
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Cache-Control');

$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security//$_POST[write]");
$thepass = $_POST["pass"];
$yourpassword = substr($file, 0, 16);

//error_reporting(0);
$myfile = fopen("$_POST[write]", "a");

//end that
if ($thepass != $yourpassword) {
die('Key incorrect');
}

//ts on?


//encoding yes
$mess = $_POST["msg"];
$emptyencode = empty($_POST["encode"]);
$coder = $_POST["encode"];

//$ip = $_SERVER['REMOTE_ADDR'];
//yes ts
$name = $_POST["namer"];


//end name gap checker
fwrite($myfile, "$mess\n");
fclose($myfile);
echo("submitted<br>");
$URL = $_SERVER['HTTP_REFERER'];
header("Location: $URL");

//no ts


?>

