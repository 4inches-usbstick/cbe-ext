<title>engine page</title>

<?php



$new = $_GET['newname'];
echo("This is a Chatbox Engine processing page. </p></p><hr>");
error_reporting(0);
echo("<b>Attempting to create new chatbox</b><p></p>");
$ok = 1;

$filename = $_GET["newname"];


if (file_exists(".hta$new")) {
    $ok = 0;
	echo("<b>Error: This chatbox number is in use.</b> <p></p>");
	die();
} else {
    echo("<p>[1] Complete </p> <p></p>");
}

$haystaq = file_get_contents('C:\wamp64\www\textengine\sitechats\.htabannednumbers');
$findme = $filename;
$pos = stristr($findme, ".");

if ($pos === false) {
    echo "[2] Complete<p></p>";
} else {
    echo "This is a forbidden Chatbox number";
	$ok = 0;
	die();
}



$haystaq = file_get_contents('C:\wamp64\www\textengine\sitechats\.htabannednumbers');
$findme = $filename;
$pos = strpos($haystaq, $findme);

if ($pos === false) {
    echo "[2] Complete<p></p>";
} else {
    echo "This is a forbidden Chatbox number";
	$ok = 0;
	die();
}

$new = $_GET['newname'];
echo("[3] Complete <p></p>");
$myfile = fopen(".hta$new", "w");

fwrite($myfile, "$_GET[newpass]<br>\n");

	
?>


