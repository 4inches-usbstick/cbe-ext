<title>engine page</title>

<?php

error_reporting(0);
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


echo('
<meta http-equiv="expires" content="Sun, 01 Jan 2014 00:00:00 GMT"/>
<meta http-equiv="pragma" content="no-cache" />
');
$file = $_GET['file'];
unlink("C:/wamp64/www/textengine/sitechats/high-security/media/$file");

$URL = $_SERVER['HTTP_REFERER'];
header("Location: $URL");
?>
