<title>engine page</title>

<?php

echo('
<meta http-equiv="expires" content="Sun, 01 Jan 2014 00:00:00 GMT"/>
<meta http-equiv="pragma" content="no-cache" />
');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
//error_reporting(0);
echo("
<noscript><b>Warning: JS is a requirement to scale file window.</b></noscript>
<div class=\"slidecontainer\">
  W<input type=\"range\" min=\"200\" max=\"1920\" value=\"720\" class=\"slider\" id=\"myRange\">
  H<input type=\"range\" min=\"100\" max=\"1080\" value=\"400\" class=\"slider\" id=\"myRange1\">

</div>


<iframe id=\"boi\" src=\"$_GET[filename]\" width=720 height=400></iframe><br>



<script>
//function newboi () {
//const iframe = document.createElement('iframe');
//iframe.id = 'boi';
//iframe.src = '$_GET[filename]';
//console.log('new iframe made');
//document.body.appendChild(iframe);
//return false;
//}





var slider = document.getElementById(\"myRange\");
var slider1 = document.getElementById(\"myRange1\");
boi.width = slider.value; 

slider.oninput = function() {
  boi.width = this.value;
}

slider1.oninput = function() {
  boi.height = this.value;
}
document.getElementById('boi').contentWindow.location.reload();


</script>
<a href='http://71.255.240.10:8080/textengine/sitechats/high-security/media/del.php?file=$_GET[filename]'>Click to Delete File</a><br>
<!--a onclick='document.getElementById('boi').contentWindow.location.reload();'>Click to Reload File Pane</a><br>




");
//$f = file_get_contents("http://71.255.240.10:8080/textengine/sitechats/high-security/media/del.php?file=$_GET[filename]");

?>
