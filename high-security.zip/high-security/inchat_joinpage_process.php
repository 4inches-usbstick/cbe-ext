<title>engine page</title>
<?php


$tolink = "inchat.php?chatnum=$_POST[nums]&refreshrate=$_POST[refreshrate]&explorer=0&encoderm=$_POST[enc]&pass=$_POST[name]";


echo("Not redirected? Use $tolink");
header("Location: $tolink");

?>

<script>
console.log("JS check passed.")
</script>





