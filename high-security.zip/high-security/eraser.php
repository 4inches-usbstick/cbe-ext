<?php
$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security/.hta$_GET[params]");
$thepass = $_GET["pass"];
$yourpassword = substr($file, 0, 16);

$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
$oktoinvite = substr_count($file, "lockout::$_SERVER[REMOTE_ADDR]");

if ($oktoinvite > 0) {
	header('HTTP/1.0 403 Forbidden');
echo('403 Forbidden: you do not have permission to interact with this resource');
die();
}

if ($iframe > 0) {
	goto bypass;
}

if ($_GET['pass'] != $yourpassword) {
header('HTTP/1.0 403 Forbidden');
echo('403 Forbidden: you do not have permission to interact with this resource');
die();
}




bypass:
$params = $_GET["params"];
$abspath = dirname($params);
$path = "C:/wamp64/www/textengine/sitechats/high-security/.hta$params";
echo($params);
echo($abspath);
echo($path);
	
//echo($path);
$haystaq = file_get_contents('C:\wamp64\www\textengine\sitechats\.htaterminalaccess');
$findme = $params;
$pos = strpos($haystaq, $findme);

if ($pos === false) {
    echo "<br>";
} else {
    echo "This file is protected and thus cannot be accessed";
	die();
}





//$ff1 = fopen($path);
//$ff1 = fclose($path);
$ff1 = unlink($path);


?>