<title>engine page</title>
<?php
echo("</p></p><hr>");
error_reporting(0);
//echo("<b>Attempting to open a chat box</b><p></p>");
$ok = 1;





$rerate = $_POST['refreshrate'];
//echo("<iframe src=$_POST[nums]></iframe>");
echo("<p></p>");
$tolink = "<a href=\"inchat.php?chatnum=.hta$_POST[nums]&refreshrate=$rerate&encoderm=$_POST[enc]&pass=$_POST[pass]\">→ Connect to the chatbox (Legacy Mode) ←</a><br>";
echo($tolink);
$tolink = "<a href=\"inchat4html.php?chatnum=$_POST[nums]&refreshrate=$rerate&explorer=0\">→ Connect to the chatbox (HTML Mode) ←</a><br>";
//echo($tolink);
$tolink = "<a href=\"inchatcss1m.php?chatnum=$_POST[nums]&refreshrate=$rerate&explorer=0\">→ Connect to the chatbox (CSS'd up) ←</a><br><br>";
//echo($tolink);


?>

<script>
console.log("JS check passed.")
</script>



<b>If the password or the Chatbox number is incorrect, it will not be shown here.</b>

