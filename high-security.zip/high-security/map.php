<title>High Security Hub</title>
<h1>CBE High Security Hub</h1>
<hr>
<a href='joinchatpublic.php'>Join Chatbox</a><br>
<a href='createnewchat.php'>Create Chatbox</a><br>
<a href='http://71.255.240.10:8080/textengine/sitechats/high-security/media/uploadform.php'>Upload File</a><br>
<a href='http://71.255.240.10:8080/textengine/sitechats/high-security/eraser-terminal.php'>Erase Chatbox</a><br><hr>

<b>Chatboxes you are a member of (via IP): </b><br><br>

<?php
$counter = 0;
foreach (glob(".hta*") as $filename) {
    $file = file_get_contents($filename);
	$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
	$oktoinvite = substr_count($file, "lockout::$_SERVER[REMOTE_ADDR]");
	
	if ($iframe > 0 && $oktoinvite == 0) {
	echo("<fieldset>You are a member of Chatbox <b>$filename</b><br><a href='inchat.php?chatnum=$filename&encoderm=UTF-8&pass=0&refreshrate=5000'>Join with default settings</a></fieldset>");
		$counter = $counter + 1;
	}

}

if ($counter == 0) {
	echo("<i>You are not a member of any Chatboxes.</i>");
}