<title>High Security Hub</title>
<h1>CBE High Security Hub</h1>
<hr>
<a href='joinchatpublic.php'>Join Chatbox</a><br>
<a href='createnewchat.php'>Create Chatbox</a><br>
<a href='http://71.255.240.10:8080/textengine/sitechats/high-security/media/uploadform.php'>Upload File</a><br>
<a href='http://71.255.240.10:8080/textengine/sitechats/high-security/eraser-terminal.php'>Erase Chatbox</a><br><hr>

<b>Chatboxes you are a member of (via IP): </b><br><br>

<?php
$counter = 0;
echo 'The Chatbox IP invite system is deprecated.'
?>