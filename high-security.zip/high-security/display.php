<title>engine page</title>

<?php
error_reporting(0);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Cache-Control');
$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security//$_GET[path]");
$thepass = $_GET["pass"];
$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
$iframe1 = substr_count($file, "invite::WILDCARD-ALL");
$oktoinvite = substr_count($file, "lockout::$_SERVER[REMOTE_ADDR]");


if ($oktoinvite > 0) {
	header('HTTP/1.0 403 Forbidden');
echo('<b>403 Forbidden: you do not have permission to interact with this resource</b>');
die();
}

if ($iframe1 > 0 && $iframe < 1) {
	$filemod = substr($file, 16);
} else {
	$filemod = $file;
}


if ($thepass == substr($file, 0, 16) || $iframe > 0 || $iframe1 > 0) {
echo("<p id='pp'>$filemod</p>


</div>
");
} else {
	header('HTTP/1.0 403 Forbidden');
echo('<b>403 Forbidden: you do not have permission to interact with this resource</b>');
}

//high security Chatboxes are locked behind a password (both the API and the web client), 
//are not visible without having access to the physical server, make use of deleteable file upload, 
//come with their own eraser utility, and cannot be edited, even with the edit extension.





?>
