

<?php
//error_reporting(0);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Cache-Control');
$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security//$_GET[path]");
$thepass = $_GET["pass"];




	$div0 = '';
	$div1 = '';
	
if ($_GET['echodiv']) {
	$div0 = '<div style="white-space: pre;">';
	$div1 = '</div>';
}


if ($thepass == substr($file, 0, 16)) {
echo("$div0 $file $div1");
} else {
	header('HTTP/1.0 403 Forbidden');
echo('<b>403 Forbidden: you do not have permission to interact with this resource</b>');
}

//high security Chatboxes are locked behind a password (both the API and the web client), 
//are not visible without having access to the physical server, make use of deleteable file upload, 
//come with their own eraser utility, and cannot be edited, even with the edit extension.





?>
