Diags
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Cache-Control');

$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security//$_GET[write]");
$thepass = $_GET["pass"];
$yourpassword = substr($file, 0, 16);

//error_reporting(0);
$myfile = fopen("$_GET[write]", "a");

//end that
if ($thepass != $yourpassword) {
die('Key incorrect');
}

//ts on?


//encoding yes
$mess = $_GET["msg"];
$emptyencode = empty($_GET["encode"]);
$coder = $_GET["encode"];

//$ip = $_SERVER['REMOTE_ADDR'];
//yes ts
$name = $_GET["namer"];


//end name gap checker
fwrite($myfile, "$mess\n");
fclose($myfile);
echo("submitted<br>");
//$URL = $_SERVER['HTTP_REFERER'];
//header("Location: $URL");

//no ts


?>



