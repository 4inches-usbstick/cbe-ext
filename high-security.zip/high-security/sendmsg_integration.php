Diags
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Cache-Control');

$file = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security//$_GET[write]");
$thepass = $_GET["pass"];
$yourpassword = substr($file, 0, 16);

$iframe = substr_count($file, "invite::$_SERVER[REMOTE_ADDR]");
$oktoinvite = substr_count($file, "lockout::$_SERVER[REMOTE_ADDR]");


if ($_GET['pass'] != $yourpassword || $oktoinvite > 0) {
	
	if ($iframe > 0) {
		goto bypass;
	}
header('HTTP/1.0 403 Forbidden');
echo('403 Forbidden: you do not have permission to interact with this resource');
die();
}

bypass:
if ($oktoinvite > 0) {
	header('HTTP/1.0 403 Forbidden');
echo('403 Forbidden: you do not have permission to interact with this resource');
die();
}


date_default_timezone_set('America/New_York');
//error_reporting(0);
$myfile = fopen("$_GET[write]", "a");

//check for iframes or js, security measure
$iframe = substr_count($_GET["msg"], 'iframe');
$script = substr_count($_GET["msg"], 'script');

if ($iframe > 0 or $script > 0) {
	die("Illegal element found in string detected, halted.<br>");
}
//end that


//ts on?
$contents = file_get_contents("C:/wamp64/www/textengine/sitechats/high-security/$_GET[write]");
//echo("$contents, C:/wamp64/www/textengine/sitechats/$_GET[write]");
$needle = "rule.Timestamps(1)";
$timestamps = strpos("$contents", "rule.Timestamps(1)");
echo("<br><br>timestamps at $timestamps<br>");

//encoding yes
$mess = $_GET["msg"];
$emptyencode = empty($_GET["encode"]);
$coder = $_GET["encode"];

if (empty($coder) or $coder == "UTF-8") {
    //echo('UTF8');
	$coder = "UTF-8";
}

$mess = $_GET["msg"];
$mess1 = mb_convert_encoding($mess, $coder);



//$ip = $_SERVER['REMOTE_ADDR'];
//yes ts
$name = $_GET["namer"];

if ($timestamps != "") {
$timestamp1 = date("H:i:s");
$timestamp2 = date("d.m.y");
$txt = "$name [$timestamp1, $timestamp2]: $mess1";
//prevent name gap

if (empty($name)) {
    $txt = "[$timestamp1, $timestamp2]: $mess1";
}

//break check
if ($mess1 == "^^br") {
    $txt = "";
}
//end name gap checker
fwrite($myfile, "$txt\n");
fclose($myfile);
echo("submitted<br>");
//$URL = $_SERVER['HTTP_REFERER'];
//header("Location: $URL");

//no ts
} else {
$txt = "$name: $mess1";
//namegapfiller
if (empty($name)) {
    $txt = "$mess1";
}
//break check
if ($mess1 == "^^br") {
    $txt = "";
}

fwrite($myfile, "$txt\n");
fclose($myfile);
echo("submitted<br>");
//$URL = $_SERVER['HTTP_REFERER'];
//header("Location: $URL");
}
echo("$coder encoder<br>");
echo("$mess1 = message<br>");
echo("$name = name<br>")
?>

<p></p>
<form>
 <input type="button" value="← Back" onclick="history.back()">
</form>


