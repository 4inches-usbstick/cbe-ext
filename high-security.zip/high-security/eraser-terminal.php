<form action="eraser.php">
  <label for="fname">Chatbox:</label><br>
  <input type="text" id="fname" name="params"><br>
  <label for="lname">Password:</label><br>
  <input type="password" id="lname" name="pass">
  <br><br>
  <input style="color:black" type="submit" value="Delete →">
</form>
