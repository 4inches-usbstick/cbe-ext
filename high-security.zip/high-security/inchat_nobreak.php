<style>

input[type=text] {
  border: 1px solid LightSlateGrey;
  border-radius: 4px;
}

input[type=text]:focus{
  outline: 2px solid Crimson;   
}
</style>

<?php
error_reporting(1);
$mediaoptions = 0;
//$gethttd = file_get_contents("http://71.255.240.10:8080/textengine/sitechats/media/$_GET[chatnum]");


if ($gethttd === false) {
	$mediaoptions = "<br>";
} else {
	$mediaoptions = "<br>";
}
	


error_reporting(0);

$coder = $_GET['encoderm'];
if (empty($_GET['encoderm'])) {
    $coder = "UTF-8";
}

echo("<title>Special Security Client</title>

");

$getter = "http://71.255.240.10:8080/textengine/sitechats/high-security/display.php?path=$_GET[chatnum]&pass=$_GET[pass]";

echo("
This cilent is specifically for operations that involve not having the br tag placed on end.<br><code style=\"color:red\" draggable=\"false\">trigger warning: this site contains flashing images. </code><br>

<hr>
<div id='mydiv' style=\"overflow:scroll; -webkit-overflow-scrolling:touch; width:700px; height:400px; white-space:pre;\">
<p id='stuff'>...</p>
</div>
<noscript><b style='color:red'>[!]: JavaScript is a requirement to use High Security Chatboxes</b></noscript>
<form action=\"sendmsg_integration.php\" method=\"GET\" autocomplete=\"off\" onsubmit=\"sendmymessagebitch();return false\">
<fieldset draggable=\"false\">
<legend>Say something: </legend>
<br>
Message: <input type=\"text\" name=\"msg\" id='msg'><br>
<input type=\"hidden\" id=\"custid1\" name=\"write\" value=\"$_GET[chatnum]\"> 
<input type=\"hidden\" id=\"custid2\" name=\"encode\" value=\"$_GET[encoderm]\"> 
<input type=\"hidden\" id=\"custid3\" name=\"pass\" value=\"$_GET[pass]\"> 
<br>


<input type=\"submit\" style=\"color:black\" value=\"Send\">
</fieldset>
</form>

  <script>
  document.addEventListener('keydown', bruhw234re);

function sendmymessagebitch() {
	var msg = document.getElementById('msg').value;
	var des = document.getElementById('custid1').value;
	var enc = document.getElementById('custid2').value;
	var nam = document.getElementById('custid3').value;
	var meaningfulname = [\"sendmsg_integration.php?msg=\",msg,\"&write=\",des,\"&encode=\",enc,\"&pass=\",nam,\"&rurl=norefer&referer=norefer\"];
	var theUrl = meaningfulname.join('');
	var boi = theUrl.concat(' :: sending request')
	console.log(boi);
	var msg = document.getElementById('msg').value = '';
	

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function() { 
			//console.log(xmlHttp.responseText);
			var boi = 'boi';
    }
	xmlHttp.open(\"GET\", theUrl, true); // true for asynchronous 
	xmlHttp.setRequestHeader(\"Cache-Control\", \"no-cache, no-store, max-age=0\");
    xmlHttp.send(null);
	}
	
function bruhw234re() {
if (event.isComposing || event.keyCode === 27) {
    document.getElementById(\"msg\").focus();
  }
}

function httpGet(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
			//console.log(xmlHttp.responseText);
			document.getElementById(\"stuff\").innerHTML = xmlHttp.responseText;
			document.getElementById(\"mydiv\").scrollTo(0,999999999999999)
    }
			var str1 = theUrl;
			var str2 = \"&ran=\";
			var str3 = Math.random();
			var res = str1.concat(str2);
			var url = res.concat(str3);
			console.log(url);
			
    xmlHttp.open(\"GET\", url, true); // true for asynchronous 
	xmlHttp.setRequestHeader(\"Cache-Control\", \"no-cache, no-store, max-age=0\");
    xmlHttp.send(null);
}

function scrollToBottom (id) {
   var div = document.getElementById(id);
   div.scrollTop = div.scrollHeight - div.clientHeight;
}




httpGet(\"$getter\");
	

   var myIframe = document.getElementById('iframe1');
//myIframe.onload = function () {
  //  myIframe.contentWindow.scrollTo(0,99999999999999999999);
//}
   var _refreshrate = $_GET[refreshrate] 
   setInterval(function(){ reloadiframe(); }, _refreshrate);


        function reloadiframe() {
            console.log('reloading..');
            httpGet(\"$getter\");
        }
		
function copy() {
  var copyText = document.querySelector(\"#input\");
  copyText.select();
  document.execCommand(\"copy\");
}

//document.querySelector(\"#copy\").addEventListener(\"click\", copy);

    </script>


<!--script>
document.getelementbyid('iframe1').contentwindow.location.reload();
</script-->





<br>
");

$theurl = "http://71.255.240.10:8080/textengine/sitechats/high-security/inchat_joinpage.php?chatnum=$_GET[chatnum]&refreshrate=$_GET[refreshrate]&explorer=0&encoderm=$coder";
echo("<textarea id=\"input\" type=\"text\" rows=\"1\" cols=\"1\" >$theurl</textarea>");


