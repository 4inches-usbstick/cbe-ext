#helo. you are most likely from CBE, you need to download something called Python, which can read and act on these script files.
ip = "71.255.240.10:8080" #(change this if you always connect to a certain server other than 71.255.240.10 port 8080)
print("Chatbox Engine Python")
print("Close this window specifically to instantly close the program")
print("-----------------------------------------")
currentcode = 0

def setcbn(take):
    global cbn
    cbn = take
    return(0)
    
def setn(take):
    global name
    name = take
    return(0)
    
def setip(take):
    global ip
    ip = take
    return(0)
    
def setrera(take):
    global rera
    rera = take
    return(0)

def setkey(take):
    global keyfile
    keyfile = take
    return(0)
    
def desini():
    iniwindow.destroy()
    
    
import tkinter as tk
print("Imported GUI package")
     
import requests
print("Imported GET package")

import modifiedenx as enx
print("Imported ENX package")

while(True):
    iniwindow = tk.Tk()
    L1 = tk.Label(text="Connect to:")
    E1 = tk.Entry()
  
    L2 = tk.Label(text="Password:")
    E2 = tk.Entry()
    
    L3 = tk.Label(text="Server IP")
    E3 = tk.Entry()
    
    L4 = tk.Label(text="Refresh rate <ms>:")
    E4 = tk.Entry()
    
    L5 = tk.Label(text="Decoding file:")
    L6 = tk.Label(text="(for encoded chatboxes only.)")
    L7 = tk.Label(text="")
    E5 = tk.Entry()
    
    iniwindow.minsize(350, 250)
   
    
    entton = tk.Button(
    text="Connect",
    width=10,
    height=1,
    bg="green",
    fg="white",
    command = lambda:[setcbn(E1.get()), setn(E2.get()), setip(E3.get()), setrera(E4.get()), setkey(E5.get()), desini() ]
    )
    
    outton = tk.Button(
    text="Quit",
    width=5,
    height=1,
    bg="red",
    fg="white",
    command = exit
    )
    
    L3.pack()
    E3.pack()
    L4.pack()
    E4.pack()
    L1.pack()
    E1.pack()
    L2.pack()
    E2.pack()
    L5.pack()
    E5.pack()
    L6.pack()
    L7.pack()
    entton.pack()
    outton.pack()
    E3.insert(tk.END, ip)
    E4.insert(tk.END, 5000)
    #E5.insert(tk.END, 'key')
    #E1.insert(tk.END, 'charles')
    #E2.insert(tk.END, '1234567812345678')
    iniwindow.title("CBE-HS Python Client")
    iniwindow.mainloop()

    
   
   

    #cbn = input("Chatbox Number > ")
    #name = input("Name in Chatbox > ")
    #rr = input("Refresh Rate (ms) > ")
    #encoder in Python is disabled, it's always on UTF-8 - encoder = input("Encoder > ")
    print("-----------------------------------------")
    
    base_send_get = "http://" +ip+ "/textengine/sitechats/high-security/sendmsg_integration.php?"
    
    print("Attempting to open " + cbn)
    
  
    
    def pullfromtheserver():
        x = requests.get("http://"+ip+"/textengine/sitechats/high-security/display.php?path=.hta" + cbn + '&pass=' + name)
        cbtxt = x.text
        cbrsc = x.status_code
        global currentcode
        currentcode = cbrsc

        if keyfile == 'false' and 'cipher::YES' not in cbtxt:
            return(cbtxt)
        #no cipher and no key, good
        elif keyfile == 'false' and 'cipher::YES' in cbtxt:
            currentcode = 40
            return 'Cipher error: no key was presented to decipher a ciphered Chatbox'
        #no key but cipher, bad
        elif keyfile != 'false' and 'cipher::YES' not in cbtxt:
            if currentcode != 200:
                currentcode = 40
                return 'Cipher error: the HTTP request failed which created a non decipherable string'
            else:
                currentcode = 40
                return 'Cipher error: a key was presented when no key was needed'
        #yes key but no cipher, bad
        elif keyfile != 'false' and 'cipher::YES' in cbtxt:
        
            #cbtxt = cbtxt[16:]
            cbtxt = cbtxt.replace('cipher::YES\n', '')
            cbtxt = cbtxt.replace(str(name)+'\n', '')
            cbtxt = cbtxt.replace('\n', '')
            cbtxt = cbtxt.replace('   ', '')
            #cbtxt = cbtxt.replace(' ', '')
            print('In:' + cbtxt)
            #yes key and cipher, ok if it goes well
            newlinecharacterdec = enx.dec('\n', keyfile)
            if newlinecharacterdec in cbtxt or len(cbtxt) < 35:
                try:
                    acbtxt = enx.dec(cbtxt, keyfile)
                    return acbtxt.replace('\\n', '\n')
                except:
                    currentcode = 40
                    return 'Cipher error: missing mapping for input character'
                #bad
                    
        else:
                currentcode = 40
                return 'Cipher error: unknown Cipher Error'

       

            
        
    
    window = tk.Tk()
    cbtex = pullfromtheserver()   
    #checktheserver()
    
    x1 = requests.get("http://"+ip+"/textengine/sitechats/high-security/display.php?path=.hta" + cbn + '&pass=' + name)
    cbrs = x1.status_code
    #cbrs = 404
    
    print("cbn: " + cbn)
    print("key: " + name)
    print("server IP: " + ip)
    print("http://"+ip+"/textengine/sitechats/high-security/display.php?path=.hta" + cbn + '&pass=' + name)
    
    if cbrs == 200:
        print("HTTP Success, response code: ")
        print(cbrs)
    if cbrs != 200:
        print("HTTP Error, reponse code: ")
        print(cbrs)
    print("-----------------------------------------")    

        
    
    
    #window.attributes("-fullscreen", True)
    #ar = "Status: Connecting"
    greeting = tk.Label(text="Chatbox Engine Python")
    
    greeting.pack()
    window.title("CBE Python Client")
    
    
    #top = tk.Frame(window)
    #bottom = tk.Frame(window) 

    #top.pack(side=TOP)
    #bottom.pack(side=BOTTOM)

    
    
    
    
    
    #label = tk.Label(
     #   text= cbtex,
      #  fg="white",
       # bg="black",
        #width=150,
        #height=30
    #)
    #label.pack()
    
    textb = tk.Text(window, height=30, width=125)
    textb.pack(expand=True, fill='both')
    textb.insert(tk.END, str(cbtex))
    
    textb.tag_configure("center", justify='left')
    
    
    
    text_box = tk.Text(
    width=100,
    height=2
    )
    text_box.pack()
    statt = tk.Label(text="Status: ...")
    statt.pack()

    if cbrs == 200:
        statt.config(text='Status: Ready')
    else:
        statt.config(text='Status: HTTP Failure on loading Chatbox ('+str(cbrs)+')')

    
    
    
    
    #nice line comment
    def deletefun(arg=1):
        global statt
        #print('ddddddd')
        inputt = text_box.get("1.0", tk.END)
        inputt1 = text_box.get("1.0", tk.END)
        inputt1 = inputt1.replace('\n', '')
        inputt1 = inputt1.replace('\r', '')
        inputt1 = inputt1.replace('\\', '')
        inputt1 = inputt1.replace(' ', '')
        if not inputt1:
            statt.config(text='Status: Cannot send an empty message')
            text_box.delete("1.0", tk.END)
            return None
        else:
            pass

        if currentcode == 40:
            statt.config(text='Status: Cipher error on loading Chatbox, which prevented message send')
            return None
        inputt = inputt.replace('\n', '')
        
        if keyfile != 'false':
            inputt = enx.enc(inputt, keyfile)
            newline = enx.enc('\\', keyfile) + enx.enc('n', keyfile)
            
        
            if 'could not encode:' in inputt:
                statt.config(text='Status: Cipher error (could not encode message)')
                return 0
            else:
                inputt = inputt + newline
        else:
            pass
        #inputt = inputt + '\n'
        text_box.delete("1.0", tk.END)
        send = requests.get(base_send_get + "msg=" + inputt + "&write=.hta" + cbn + "&rurl=norefer&pass=" + name + "&encode=")
        print("Debug:")
        print(base_send_get + "msg=" + inputt + "&write=.hta" + cbn + "&rurl=norefer&pass=" + name + "&encode=")
        print(send.status_code)
        if int(send.status_code) == 200:
            statt.config(text='Status: Message sent')
        else:
            statt.config(text='Status: HTTP Failure on sending message ('+str(send.status_code)+')')
        #print(send.text)
        return None
    def endsession():
        window.destroy()
        
    button = tk.Button(
        text="Send",
        width=10,
        height=1,
        bg="green",
        fg="white",
        command = deletefun,
    )
  
    delbutton = tk.Button(
        text="Exit this Chatbox",
        width=15,
        height=1,
        bg="red",
        fg="white",
        command = endsession,
    )




    #statt.insert('1.0', 'here is my\ntext to insert')
    #var.set("Status: Ready")
    
    window.bind('<Return>',deletefun)
    button.pack()
    delbutton.pack()
    
    #b.grid(row=0,column=0, sticky=W)
    #c.grid(row=0,column=1, sticky=W)
    
  
    
    
    
    
    #myscroll = ttk.Scrollbar(window, orient='vertical', command=myentry.xview)
    
    def my_mainloop():
        newtext = pullfromtheserver()
        #print(newtext)
        textb.delete('1.0', tk.END)
        textb.insert(tk.END, newtext)
        textb.see(tk.END)
        window.after(rera, my_mainloop)

        if int(currentcode) == 200:
            statt.config(text='Status: Ready')
        elif int(currentcode) == 40:
            statt.config(text='Status: Cipher error (see Chatbox contents)')
        else:
            statt.config(text='Status: HTTP Failure on loading Chatbox ('+str(cbrs)+')')
    
    window.after(1000, my_mainloop)
    window.resizable(height = 1000, width = 1000)
       

    
    window.mainloop()
    
    
